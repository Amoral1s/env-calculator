<?php get_header(); ?>

<section class="vac-offer blog-page error-404 not-found">
	<div class="container">
		<div class="blog-page-search search">
      <?php echo do_shortcode('[wpdreams_ajaxsearchlite]'); ?>
    </div>
		<h1 class="page-title" style="text-align: center;">404</h1>
		<a href="/" class="button button-accent">Home page</a>
	</div>
</section><!-- .error-404 -->

<?php get_footer(); ?>
