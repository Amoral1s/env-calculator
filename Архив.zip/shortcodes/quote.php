<section class="get">
  <div class="get-wrap">
    <b>Get a quote</b>
    <p>Please provide us details for your move. Its free and takes only 30 seconds</p>
    <div class="get-form">
      <div class="input">
        <input type="text" class="input-from" placeholder="Moving from">
        <p>Moving from</p>
      </div>
      <div class="input">
        <input type="text" class="input-to" placeholder="Moving to">
        <p>Moving to</p>
      </div>
      <a href="<?php the_permalink(79); ?>" class="button">
        Quote
      </a>
    </div>
  </div>
</section>